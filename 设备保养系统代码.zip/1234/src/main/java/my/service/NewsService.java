package my.service;

import java.util.List;

import my.dao.NewsDao;
import my.entity.News;

public class NewsService {
	public NewsService() {
		super();
	}
	private NewsDao newsDao;

	public void setNewsDao(NewsDao newsDao) {
		this.newsDao = newsDao;
	}
	
	public NewsService(NewsDao newsDao){
		this.newsDao = newsDao;
	}

	public News getById(int id){
		return newsDao.getById(id);
	}

}
