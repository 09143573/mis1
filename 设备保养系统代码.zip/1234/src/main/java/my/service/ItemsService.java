package my.service;

import java.util.ArrayList;

import my.dao.ItemsDao;
import my.entity.Items;

public class ItemsService {
	public ItemsService() {
		super();
	}
	public ItemsDao getItemsDao() {
		return itemsDao;
	}
	public void setItemsDao(ItemsDao itemsDao) {
		this.itemsDao = itemsDao;
	}
	private ItemsDao itemsDao;
	public boolean addItems(Items items) {
		// TODO Auto-generated method stub
		return itemsDao.addItems(items);
	}
	public boolean addItems1(Items items) {
		// TODO Auto-generated method stub
		return itemsDao.addItems1(items);
	}
	

}