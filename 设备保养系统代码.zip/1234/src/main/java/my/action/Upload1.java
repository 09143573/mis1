package my.action;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;

import java.io.File;

import com.opensymphony.xwork2.ActionSupport;

import my.dao.ItemsDaoJDBCImpl;
import my.entity.Items;
import my.service.ItemsService;

public class Upload1 extends ActionSupport  implements ServletRequestAware{		
		private int baoyangjiluID;
		private String cailiaomingcheng;
		private int baoyangxiaohaoID;
		private int number;
		private String danwei;
		private HttpServletRequest request;
		private HttpSession session;
		private ServletContext application;
		public void setServletRequest(HttpServletRequest request){

			this.request = request;

			this.session= request.getSession();

			this.application = session.getServletContext();

			}
		public int getNumber() {
			return number;
		}
		public void setNumber(int number) {
			this.number = number;
		}
		public int getBaoyangxiaohaoID() {
			return baoyangxiaohaoID;
		}
		public void setBaoyangxiaohaoID(int baoyangxiaohaoID) {
			this.baoyangxiaohaoID = baoyangxiaohaoID;
		}public int getBaoyangjiluID() {
			return baoyangjiluID;
		}
		public void setBaoyangjiluID(int baoyangjiluID) {
			this.baoyangjiluID = baoyangjiluID;
		}
		public String getCailiaomingcheng() {
			return cailiaomingcheng;
		}
		public void setCailiaomingcheng(String cailiaomingcheng) {
			this.cailiaomingcheng = cailiaomingcheng;
		}
		public String getDanwei() {
			return danwei;
		}
		public void setDanwei(String danwei) {
			this.danwei =danwei;
		}


		//��װ�ϴ��ļ��������
		private File upload;
		//��װ�ϴ��ļ����͵�����
		private String uploadContentType;
		//��װ�ϴ��ļ���������
		private String uploadFileName;
		//ֱ����struts.xml�ļ������õ�����
		private String savePath;
		//����struts.xml�ļ�����ֵ�ķ���
		public void setSavePath(String value)
		{
			this.savePath = value;
		}
		//�����ϴ��ļ��ı���λ��
		private String getSavePath() throws Exception
		{
			return ServletActionContext.getServletContext()
				.getRealPath(savePath);
		}
		//�ϴ��ļ���Ӧ�ļ����ݵ�setter��getter����
		public void setUpload(File upload)
		{
			this.upload = upload;
		}
		public File getUpload()
		{
			return (this.upload);
		}

		//�ϴ��ļ����ļ����͵�setter��getter����
		public void setUploadContentType(String uploadContentType)
		{
			this.uploadContentType = uploadContentType;
		}
		public String getUploadContentType()
		{
			return (this.uploadContentType);
		}

		//�ϴ��ļ����ļ�����setter��getter����
		public void setUploadFileName(String uploadFileName)
		{
			this.uploadFileName = uploadFileName;
		}
		public String getUploadFileName()
		{
			return (this.uploadFileName);
		}

		@Override
		public String execute() throws Exception
		{
			//�Է��������ļ������ַ��ԭ�ļ��������ϴ��ļ������
			FileOutputStream fos = new FileOutputStream(getSavePath()
				+ "\\" + getUploadFileName());
			FileInputStream fis=new FileInputStream(getUpload());
			byte[] buffer = new byte[1024];
			int len = 0;
			while ((len = fis.read(buffer)) > 0)
			{
				fos.write(buffer , 0 , len);
			}
			fos.close();
			ItemsService itemsService=new ItemsService();
			ItemsDaoJDBCImpl itemsDaoJDBCImpl=new ItemsDaoJDBCImpl();
			itemsService.setItemsDao(itemsDaoJDBCImpl);
			Items items=new Items();
			items.setBaoyangjiluID(getBaoyangjiluID());
			items.setBaoyangxiaohaoID(getBaoyangxiaohaoID());
			items.setNumber(getNumber());
			items.setCailiaomingcheng(getCailiaomingcheng());
			items.setDanwei(getDanwei());
			itemsService.addItems1(items);
			return SUCCESS;
		}
		

}
