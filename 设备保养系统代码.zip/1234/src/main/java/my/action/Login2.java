package my.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import my.dao.NewsDaoJDBCImpl;
import my.entity.News;
import my.service.NewsService;


public class Login2 extends ActionSupport {
	private NewsService newsService=new NewsService();
	private String username;
	private String password;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	
	}
	public NewsService getNewsService() {
		return newsService;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	@Override
	public String execute() {
		NewsDaoJDBCImpl newsDaoJDBCImpl=new NewsDaoJDBCImpl();
		newsService.setNewsDao(newsDaoJDBCImpl);
		 ActionContext news1=ActionContext.getContext();
	     News news=new News();
	     news.setUsername(getUsername());
 	     news.setPassword(getPassword());
    		 if(news.getPassword().equals(getPassword()) && news.getUsername().equals(getUsername())){
    			
                 return SUCCESS;
    		}else{
    		 addActionMessage("�Բ�����������������������");
    		 return ERROR;
    		}
    	}

	  
	}

