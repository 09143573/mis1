package my.action;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;

import java.io.File;

import com.opensymphony.xwork2.ActionSupport;

import my.dao.ItemsDaoJDBCImpl;
import my.entity.Items;
import my.service.ItemsService;

public class Upload extends ActionSupport  implements ServletRequestAware{		
		private int baoyangjiluID;
		private String baoyangren;
		private int baoyangxiangmuID;
		private int shebeiID;
		private String time;
		private String done;
		private HttpServletRequest request;
		private HttpSession session;
		private ServletContext application;
		public void setServletRequest(HttpServletRequest request){

			this.request = request;

			this.session= request.getSession();

			this.application = session.getServletContext();

			}
		public int getShebeiID() {
			return shebeiID;
		}
		public void setShebeiID(int shebeiID) {
			this.shebeiID = shebeiID;
		}
		public int getBaoyangxiangmuID() {
			return baoyangxiangmuID;
		}
		public void setBaoyangxiangmuID(int baoyangxiangmuID) {
			this.baoyangxiangmuID = baoyangxiangmuID;
		}public int getBaoyangjiluID() {
			return baoyangjiluID;
		}
		public void setBaoyangjiluID(int baoyangjiluID) {
			this.baoyangjiluID = baoyangjiluID;
		}
		public String getBaoyangren() {
			return baoyangren;
		}
		public void setBaoyangren(String baoyangren) {
			this.baoyangren = baoyangren;
		}
		public String getDone() {
			return done;
		}
		public void setDone(String done) {
			this.done = done;
		}
		public String getTime() {
			return time;
		}
		public void setTime(String time) {
			this.time = time;
		}

		//��װ�ϴ��ļ��������
		private File upload;
		//��װ�ϴ��ļ����͵�����
		private String uploadContentType;
		//��װ�ϴ��ļ���������
		private String uploadFileName;
		//ֱ����struts.xml�ļ������õ�����
		private String savePath;
		//����struts.xml�ļ�����ֵ�ķ���
		public void setSavePath(String value)
		{
			this.savePath = value;
		}
		//�����ϴ��ļ��ı���λ��
		private String getSavePath() throws Exception
		{
			return ServletActionContext.getServletContext()
				.getRealPath(savePath);
		}
		//�ϴ��ļ���Ӧ�ļ����ݵ�setter��getter����
		public void setUpload(File upload)
		{
			this.upload = upload;
		}
		public File getUpload()
		{
			return (this.upload);
		}

		//�ϴ��ļ����ļ����͵�setter��getter����
		public void setUploadContentType(String uploadContentType)
		{
			this.uploadContentType = uploadContentType;
		}
		public String getUploadContentType()
		{
			return (this.uploadContentType);
		}

		//�ϴ��ļ����ļ�����setter��getter����
		public void setUploadFileName(String uploadFileName)
		{
			this.uploadFileName = uploadFileName;
		}
		public String getUploadFileName()
		{
			return (this.uploadFileName);
		}

		@Override
		public String execute() throws Exception
		{
			//�Է��������ļ������ַ��ԭ�ļ��������ϴ��ļ������
			FileOutputStream fos = new FileOutputStream(getSavePath()
				+ "\\" + getUploadFileName());
			FileInputStream fis=new FileInputStream(getUpload());
			byte[] buffer = new byte[1024];
			int len = 0;
			while ((len = fis.read(buffer)) > 0)
			{
				fos.write(buffer , 0 , len);
			}
			fos.close();
			ItemsService itemsService=new ItemsService();
			ItemsDaoJDBCImpl itemsDaoJDBCImpl=new ItemsDaoJDBCImpl();
			itemsService.setItemsDao(itemsDaoJDBCImpl);
			Items items=new Items();
			items.setBaoyangjiluID(getBaoyangjiluID());
			items.setBaoyangxiangmuID(getBaoyangxiangmuID());
			items.setShebeiID(getShebeiID());
			items.setBaoyangren(getBaoyangren());
			items.setTime(getTime());
			items.setDone(getDone());
			
			itemsService.addItems(items);
			return SUCCESS;
		}
		

}
