package my.dao;

import java.util.List;


import my.entity.News;

public interface NewsDao {
	public News getById(int id);

	
}
