package my.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import my.dbutil.DbUtil;
import my.entity.Items;

public class ItemsDaoJDBCImpl implements ItemsDao {

	@Override
	public boolean addItems(Items items) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("insert into baoyangjilu values(?,?,?,?,?,?)",new Object[]{items.getBaoyangjiluID(),items.getShebeiID(),items.getBaoyangxiangmuID(),items.getBaoyangren(),items.getDone(),items.getTime()});		
	}
	@Override
	public boolean addItems1(Items items) {
		// TODO Auto-generated method stub
		return DbUtil.executeUpdate("insert into baoyangxiaohao values(?,?,?,?,?)",new Object[]{items.getBaoyangxiaohaoID(),items.getBaoyangjiluID(),items.getCailiaomingcheng(),items.getNumber(),items.getDanwei()});		
	}
}

