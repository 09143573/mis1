package my.dao;

import java.util.ArrayList;

import my.entity.Items;

public interface ItemsDao {
	
	public boolean addItems(Items items);
	public boolean addItems1(Items items);
}
