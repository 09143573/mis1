package my.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import my.dbutil.DbUtil;

import my.entity.News;

public class NewsDaoJDBCImpl implements NewsDao {

	

	@Override
	public News getById(int id) {
		// TODO Auto-generated method stub
		ResultSet rs=DbUtil.executeQuery("select * from user where username=?", new Object[]{id});
		News news=null;
		try{
			while(rs.next()){
				news=new News();
				news.setUsername(rs.getString(1));
				news.setPassword(rs.getString(2));
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return news;
	}

}
