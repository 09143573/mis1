package my.entity;

public class Items {
	private int baoyangjiluID;
	private String baoyangren;
	private int baoyangxiangmuID;
	private int shebeiID;
	private String time;
	private String done;
	private String cailiaomingcheng;
	private int baoyangxiaohaoID;
	private int number;
	private String danwei;
	public int getShebeiID() {
		return shebeiID;
	}
	public void setShebeiID(int shebeiID) {
		this.shebeiID = shebeiID;
	}
	public int getBaoyangxiangmuID() {
		return baoyangxiangmuID;
	}
	public void setBaoyangxiangmuID(int baoyangxiangmuID) {
		this.baoyangxiangmuID = baoyangxiangmuID;
	}public int getBaoyangjiluID() {
		return baoyangjiluID;
	}
	public void setBaoyangjiluID(int baoyangjiluID) {
		this.baoyangjiluID = baoyangjiluID;
	}
	public String getBaoyangren() {
		return baoyangren;
	}
	public void setBaoyangren(String baoyangren) {
		this.baoyangren = baoyangren;
	}
	public String getDone() {
		return done;
	}
	public void setDone(String done) {
		this.done = done;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public int getBaoyangxiaohaoID() {
		return baoyangxiaohaoID;
	}
	public void setBaoyangxiaohaoID(int baoyangxiaohaoID) {
		this.baoyangxiaohaoID = baoyangxiaohaoID;
	}
	public String getCailiaomingcheng() {
		return cailiaomingcheng;
	}
	public void setCailiaomingcheng(String cailiaomingcheng) {
		this.cailiaomingcheng = cailiaomingcheng;
	}
	public String getDanwei() {
		return danwei;
	}
	public void setDanwei(String danwei) {
		this.danwei =danwei;
	}

}
