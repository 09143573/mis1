$(function() {

    $('#leftNavigation').ssdVerticalNavigation();

});