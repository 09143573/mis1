CREATE DATABASE  IF NOT EXISTS `shebeibaoyang` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `shebeibaoyang`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: shebeibaoyang
-- ------------------------------------------------------
-- Server version	5.7.11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `baoyangxiaohao`
--

DROP TABLE IF EXISTS `baoyangxiaohao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `baoyangxiaohao` (
  `baoyangxiaohaoID` int(11) NOT NULL,
  `baoyangjiluID` int(11) NOT NULL,
  `cailiaomingcheng` varchar(45) NOT NULL,
  `number` int(11) NOT NULL,
  `danwei` varchar(45) NOT NULL,
  PRIMARY KEY (`baoyangxiaohaoID`),
  KEY `k5_idx` (`baoyangjiluID`),
  CONSTRAINT `k5` FOREIGN KEY (`baoyangjiluID`) REFERENCES `baoyangjilu` (`baoyangjiluID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `baoyangxiaohao`
--

LOCK TABLES `baoyangxiaohao` WRITE;
/*!40000 ALTER TABLE `baoyangxiaohao` DISABLE KEYS */;
INSERT INTO `baoyangxiaohao` VALUES (1,1,'电线',2,'根');
/*!40000 ALTER TABLE `baoyangxiaohao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `baoyangjilu`
--

DROP TABLE IF EXISTS `baoyangjilu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `baoyangjilu` (
  `baoyangjiluID` int(11) NOT NULL,
  `shebeiID` int(11) NOT NULL,
  `baoyangxiangmuID` int(11) NOT NULL,
  `baoyangren` varchar(45) NOT NULL,
  `done` varchar(45) NOT NULL,
  `time` date NOT NULL,
  PRIMARY KEY (`baoyangjiluID`),
  KEY `k3_idx` (`shebeiID`),
  KEY `k4_idx` (`baoyangxiangmuID`),
  CONSTRAINT `k3` FOREIGN KEY (`shebeiID`) REFERENCES `shebei` (`shebeiID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `k4` FOREIGN KEY (`baoyangxiangmuID`) REFERENCES `baoyangxiangmu` (`baoyangxiangmuID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `baoyangjilu`
--

LOCK TABLES `baoyangjilu` WRITE;
/*!40000 ALTER TABLE `baoyangjilu` DISABLE KEYS */;
INSERT INTO `baoyangjilu` VALUES (1,1,1,'aa','完成','2016-10-11'),(2,1,2,'a','完成','2016-10-13'),(3,2,4,'b','完成','2016-10-10');
/*!40000 ALTER TABLE `baoyangjilu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `baoyangxiangmu`
--

DROP TABLE IF EXISTS `baoyangxiangmu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `baoyangxiangmu` (
  `baoyangxiangmuID` int(11) NOT NULL,
  `shebeileixingID` int(11) NOT NULL,
  `xiangmumingcheng` varchar(45) NOT NULL,
  PRIMARY KEY (`baoyangxiangmuID`),
  KEY `k2_idx` (`shebeileixingID`),
  CONSTRAINT `k2` FOREIGN KEY (`shebeileixingID`) REFERENCES `shebeileixing` (`shebeileixingID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `baoyangxiangmu`
--

LOCK TABLES `baoyangxiangmu` WRITE;
/*!40000 ALTER TABLE `baoyangxiangmu` DISABLE KEYS */;
INSERT INTO `baoyangxiangmu` VALUES (1,2,'防冻液喷洒系统电磁阀密封、防腐检'),(2,2,'防冻液喷洒系统泵和液压站电机接线、密封、防腐；'),(3,2,'防冻液喷洒系统现场开关检查、接线箱接线、密封、防腐；'),(4,5,'校对液位仪准确度');
/*!40000 ALTER TABLE `baoyangxiangmu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `username` varchar(45) NOT NULL,
  `userpwd` int(11) NOT NULL,
  `officer` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('123',123,NULL),('321',321,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shebei`
--

DROP TABLE IF EXISTS `shebei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shebei` (
  `shebeiID` int(11) NOT NULL,
  `shebeileixingID` int(11) NOT NULL,
  `thelasttime` date NOT NULL,
  PRIMARY KEY (`shebeiID`),
  KEY `k1_idx` (`shebeileixingID`),
  CONSTRAINT `k1` FOREIGN KEY (`shebeileixingID`) REFERENCES `shebeileixing` (`shebeileixingID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shebei`
--

LOCK TABLES `shebei` WRITE;
/*!40000 ALTER TABLE `shebei` DISABLE KEYS */;
INSERT INTO `shebei` VALUES (1,2,'2016-10-11'),(2,5,'2016-10-10'),(3,16,'2016-10-10'),(4,18,'2016-10-09'),(5,2,'2016-10-11');
/*!40000 ALTER TABLE `shebei` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shebeileixing`
--

DROP TABLE IF EXISTS `shebeileixing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shebeileixing` (
  `shebeileixingID` int(11) NOT NULL,
  `shebeileixing` varchar(45) NOT NULL,
  `baoyangzhouqi` int(11) NOT NULL,
  `tiqian` int(11) NOT NULL,
  `extra` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`shebeileixingID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shebeileixing`
--

LOCK TABLES `shebeileixing` WRITE;
/*!40000 ALTER TABLE `shebeileixing` DISABLE KEYS */;
INSERT INTO `shebeileixing` VALUES (2,'防冻液喷洒shebei',7,2,'11月20日-4月1日'),(5,'桶位仪',30,5,NULL),(16,'振动筛电机',180,7,NULL),(18,'球磨机',365,20,NULL);
/*!40000 ALTER TABLE `shebeileixing` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-02 16:10:14
